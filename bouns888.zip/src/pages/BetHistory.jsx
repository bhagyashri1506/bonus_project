import React from 'react'
import Footer from '../components/Footer'
import Header from '../components/Header'

function Bets() {
    return (
        <div id="menu-notifications"
            class="rounded-m d-block mx-2"
        // style={{ backgroundColor: "#fff" }}
        >
            <div class="menu-size" style={{ height: "75vh" }}>
                <div class="content pb-2">
                    <a href="#" class="d-flex py-1 justify-content-between">
                        <div class="align-self-center ps-1">
                            <h5 class="pt-1 mb-n1 color_yellow">Meg888 - Slot 1 Bet $100 Win $100</h5>
                            <p class="mb-0 font-11 opacity-70 color-white">14th March 03:14 AM</p>
                        </div>
                    </a>
                    <div class="divider my-2 opacity-50"></div>
                    <a href="#" class="d-flex py-1 justify-content-between">
                        <div class="align-self-center ps-1">
                            <h5 class="pt-1 mb-n1 color_yellow">Meg888 - Slot 1 Bet $100 Win $100</h5>
                            <p class="mb-0 font-11 opacity-70 color-white">14th March 03:14 AM</p>
                        </div>
                    </a>
                    <div class="divider my-2 opacity-50"></div>
                    <a href="#" class="d-flex py-1 justify-content-between">
                        <div class="align-self-center ps-1">
                            <h5 class="pt-1 mb-n1 color_yellow">Meg888 - Slot 1 Bet $100 Lose $10</h5>
                            <p class="mb-0 font-11 opacity-70 color-white">14th March 03:14 AM</p>
                        </div>
                    </a>
                    <div class="divider my-2 opacity-50"></div>
                    <a href="#" class="d-flex py-1 justify-content-between">
                        <div class="align-self-center ps-1">
                            <h5 class="pt-1 mb-n1 color_yellow">Meg888 - Slot 1 Bet $100 Win $100</h5>
                            <p class="mb-0 font-11 opacity-70 color-white">14th March 03:14 AM</p>
                        </div>
                    </a>
                    <div class="divider my-2"></div>
                </div>
            </div>
        </div>
    )
}

export default Bets