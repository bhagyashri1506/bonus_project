import React from 'react'
import Header from './Header'
import Footer from './Footer'

const LiveChat = () => {
    return (
        <div className="t1" style={{height:"calc(100vh - 110px)", overflowY:"auto"}}>
            <Header />
           <div>
           <div id="livechat">
                <div className="time">9:32pm</div>
                <div className="msg">
                    <div className="msg_wrapper">
                        <span className='name'>ALI ABU</span>
                        <span className='txt'>Join</span>
                    </div>
                </div>
                <div className="msg">
                    <div className="msg_wrapper">
                        <span className="name">System</span>
                        <span className="txt">
                        🎉 Tahniah Anda Berjaya Daftar Di 🎉
                        <br />
                        <br />
                        🌺 BONUS888 🌺
                        <br />
                        <br />
                        Click The Link Below To Login
                        <br />
                        <br />
                        🌐 Website：
                        <a href="" target='_blank'>https://bonus888b.com</a>
                        <br />
                        <br />
                        Username：60165222860
                        <br />
                        Password：000000 (Sila Tukar)
                        <br />
                        <br />
                        ‼️IMPORTANT NOTICE‼️
                        <br />
                        <br />
                        Dear Customer,
                        <br />
                        Find Us On(LIVE CHAT)
                        <br />
                        <b style={{color:"gold"}}>Do Not Ask Or Leave A Message On WHATSAPP</b>
                        <br />
                        Thank You...Love You❤️
                        <br />
                        <br />
                        <br />
                        【🧧Cara Register Website】
                        <a href="">SINI</a>
                        <br />
                        【🧧Cara CLAIM FREE】
                        <a href="">SINI</a>
                        <br />
                        【🧧Cara "I1BAYAR" Online Transfer】
                        <a href="">SINI</a>
                        <br />
                        【🧧Cara CDM/ATM Topup】
                        <a href="">SINI</a>
                        <br />
                        【🧧Cara Withdraw】
                        <a href="">SINI</a>
                        <br />
                        【🧧Cara Untung 5% Commission】
                        <a href="">SINI</a>
                        <br />
                        【🧧Cara Game ID & Download Game】
                        <a href="">SINI</a>
                        <br />
                        【🧧Cara 5% Rebate】
                        <a href="">SINI</a>
                        <br />
                        <br />
                        <br />
                        ⚠️Notice 
                        <b color='gold'>
                            <b style={{textDecoration:"underline"}}>FREE CREDIT</b>
                        </b>
                        Cashout⚠️
                        <br />
                        <br />
                        Random Angpao Dari RM0.20-RM88.00, FREE CREDIT 
                        <b style={{color:"gold"}}>Setiap Hari 3Jam </b>
                        <b style={{color:"gold"}}>
                            <b style={{textDecoration:"underline"}}>"Unlimited No Deposit Claim"</b>
                        </b>
                        🧧🧧🧧Jangan Lupa "SHARE" Web Kami Kepada Kawan2
                        <br />
                        <br />
                        -Jika 
                        <b style={{color:"gold"}}>
                            <b style={{textDecoration:"underline"}}>FREE CREDIT</b>
                        </b>
                        Nak Cuci , 
                        <b style={{color:"red"}}>BANK ACC / HOLDER NAME / BANK NAME</b>
                        Tidak Isi Yang Betul
                        <br />
                        -Anda Tidak Dapat Dicuci Ye!! Kurang 1 Huruf Pun Tidak Boleh Dicuci, 
                        <b style={{color:"red"}}>No Excuse</b>
                        "!!"
                        <br />
                        <br />
                        ✅Jika Buat 
                        <b color='gold'>
                            <b style={{textDecoration:"underline"}}>Deposit Boleh Tukar Bank Acc</b>
                        </b>
                        【Sebelum Deposit Wallet Anda Mesti Kredit Kosong. Terima Kasih👍🤝】
                        </span>
                    </div>
                </div>
             
            </div>
           </div>
           <div className='chat_msg'>
           <div className="chat-tools">
                  <textarea placeholder="Text here..."></textarea>
                    <i class="fa-solid fa-paper-plane tool"></i>
                    <i class="fa-solid fa-paperclip tool file"></i>
                </div>
           </div>
            <Footer />
        </div>
    )
}

export default LiveChat